<?php
use core\Migration;

class m211115_078561_amocrm_fields extends Migration
{
	public function up()
	{
		$this->query("CREATE TABLE `amocrm_fields` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255) NULL DEFAULT NULL,
	`type` VARCHAR(255) NULL DEFAULT NULL,
	`name_in_form` VARCHAR(255) NULL DEFAULT NULL,
	`is_api_only` INT(11) NULL DEFAULT NULL,
	`id_field` INT(11) NULL DEFAULT NULL,
	`category` INT(11) NULL DEFAULT NULL,
	`code` VARCHAR(255) NULL DEFAULT NULL,
	PRIMARY KEY (`id`),
	INDEX `name` (`name`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=9
;
");

	}

	public function down() {
		$this->query("DROP TABLE `amocrm_fields` ");
	}
}