# AmoCrm
Работает на версии PHP >=7.2.24! 
Подключение к ЛК AmoCrm
Подключение по Api к аккаунту AmoCRM. 
Добавление, удаление и редактирование полей, а так же отправка формы методом system/modules/amocrm/controllers/amo/Leads

