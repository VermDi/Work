<div class="btn-group" style="width:100%; padding: 5px 0; background: white;" id="menu_marketing">
	<a style="margin: 5px;" href="/amocrm/admin" class="btn btn-info">Настройки подключение AmoCRM</a>
	<a style="margin: 5px;" href="/amocrm/admin/fields" class="btn btn-info">Поля</a>
</div>
