<?php


namespace modules\amocrm\models;


use core\Model;

class AmoCRMFieldsItems extends Model
{
	public $table = 'amocrm_fields_items';
}

