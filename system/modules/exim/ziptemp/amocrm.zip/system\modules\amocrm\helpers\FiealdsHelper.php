<?php

namespace modules\amocrm\helpers;


class FiealdsHelper
{
	public static $field_type = [
		'text'    => 'Текст',
		'numeric' => 'Число',
	];
	public static $category   = [
		'1' => 'Сделка',
		'2' => 'Контакт',
	];
}