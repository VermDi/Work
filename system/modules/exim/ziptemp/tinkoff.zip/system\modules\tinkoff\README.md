# Tinkoff Bank - Кнопка Кредитования/Рассрочка
Админка 
/tinkoff/admin/manual - Инструкция по интеграции кнопки на проект
/tinkoff/admin - Настройка кнопки и подключения к ЛК Tinkoff

