<?php
namespace modules\recaptcha\widgets;

use modules\menu\widgets\Widget;
use modules\recaptcha\models\mRecaptcha;
use modules\recaptcha\services\sRecaptcha;

class wRecaptcha extends Widget
{

    /**
     * Вставьте в шаблон подключение скрипта
     */
    public static function showTemplate()
    {
        echo '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
    }


    /**
     * Вставьте галочку в форму
     */
    public static function showForm()
    {
        $ActiveRecaptcha = mRecaptcha::instance()->getActiveRecaptcha();
        if(!empty($ActiveRecaptcha->id)){
            echo '<div class="g-recaptcha" data-sitekey="'.$ActiveRecaptcha->publickey.'"></div>';
        }
    }

    /**
     * Проверка формы, вставьте в обработку формы
     * @return bool
     */
    public static function checkForm()
    {
        $ActiveRecaptcha = mRecaptcha::instance()->getActiveRecaptcha();
        if(empty($ActiveRecaptcha->id)){
            return true;
        }
        return sRecaptcha::instance()->checkRecaptcha($ActiveRecaptcha->response_name, $ActiveRecaptcha->privatekey);
    }

    /**
     * Сброс капчи в случае неудачи
     */
    public static function restartRecaptcha(){
        ?>
        <script>
            if(document.getElementsByClassName('g-recaptcha').length){
                grecaptcha.reset();
            }
        </script>
        <?php
    }



}