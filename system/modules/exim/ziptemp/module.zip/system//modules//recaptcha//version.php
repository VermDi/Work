<?php
return [
    'version' => '1.0',
    'ModuleInfo' => [
        'name' => 'recaptcha',
        'version_description' => 'Вставляйте капчу в любую форму на сайте, на главной странице капчи написана подробная инструкция',
        'link_home' => '/recaptcha',
    ],
    'Folders' => [ // папки для архивации. По умолчанию system/modules/NameModule и www/assets/modules/NameModule
        'system/modules/recaptcha',
        'www/assets/modules/recaptcha',
    ],
    'requireModules' => [ // дополнительные модули, которые требует данный модуль чтобы работать. По умолчанию их нет
    ],
];
