<? $model = $data['model']; ?>
<div class="col-sm-12">
    <p><b>reCAPTCHA v2</b></p>
    <p>1. Создание рекапчи. Перейдите по <a target="_blank" href="https://www.google.com/u/1/recaptcha/admin/create">ссылке</a>, выберите reCAPTCHA v2 и введите домен <?= $_SERVER['HTTP_HOST'] ?></p>
    <p>2. Заполните поля ниже и нажмите сохранить</p>
    <div style="display: table;width: 100%;">
        <form action="/recaptcha/save" method="post" enctype="multipart/form-data" class="RecaptchaForm">
            <div class="col-sm-12">
                <input type="hidden" name="id" value="<?= $data['id']; ?>">
                <input type="hidden" name="response_name" value="<?= (!empty($model->response_name))?$model->response_name:'g-recaptcha-response'; ?>">
                <div>
                    <label for="name" class="smalllabel">ключ сайта</label>
                    <input type="text" name="publickey" value="<?= $model->publickey; ?>" class="form-control input-sm" required>
                </div>
                <div>
                    <label for="name" class="smalllabel">секретный ключ</label>
                    <input type="text" name="privatekey" value="<?= $model->privatekey; ?>" class="form-control input-sm" required>
                </div>
                <div>
                    <label for="name" class="smalllabel">Статус</label>
                    <? $name = 'status'; ?>
                    <select class="form-control" name="<?= $name; ?>">
                        <?php
                        $SelectArr = \modules\recaptcha\models\mRecaptcha::instance()->getStatusArr();
                        foreach ($SelectArr as $Key => $Name) {
                            $selected = '';
                            if(isset($model->$name) && $model->$name==$Key){
                                $selected = 'selected';
                            }
                            ?><option <?= $selected; ?> value="<?= $Key; ?>"><?= $Name; ?></option><?
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-success col-sm-12" style="margin-top: 15px;">сохранить</button>
            </div>
        </form>
    </div>
    <div>
        <br>
        <p>3. Вставьте в шаблон</p>
        <p>&lt;?php \modules\recaptcha\widgets\wRecaptcha::showTemplate(); ?&gt;</p>
        <br>
        <p>4. Вставьте в форму в шаблоне для вывода капчи</p>
        <p>&lt;?php \modules\recaptcha\widgets\wRecaptcha::showForm(); ?&gt;</p>
        <br>
        <p>5. Вставьте в обработку формы</p>
        <p>&lt;?php if(!\modules\recaptcha\widgets\wRecaptcha::checkForm()){
        exit(json_encode([&#039;error&#039; =&gt; 1, &#039;data&#039; =&gt; &#039;Ошибка, Recaptcha не пройдена&#039;]));
        } ?&gt;</p>
        <br>
        <p>6. Вставьте в js для сброса капчи</p>
        <p>&lt;script&gt;
        if(document.getElementsByClassName('g-recaptcha').length){
        grecaptcha.reset();
        }
        &lt;/script&gt;</p>
    </div>

</div>