<?php

namespace modules\recaptcha\controllers;

use core\Controller;
use core\Html;
use modules\aboutproject\models\mAboutProject;
use modules\recaptcha\models\mRecaptcha;

class Index extends Controller
{
    public function actionIndex()
    {
        header('Location: /recaptcha/form/1');
    }

    public function actionForm($id=false)
    {
        if (empty($id)) {
            header('Location: /recaptcha/form/1');
        }
        $data['id']=$id;
        $data['model'] = mRecaptcha::instance()->factory($id);

        Html::instance()->setCss('/assets/vendors/toastr-master/toastr.css');
        Html::instance()->setJs('/assets/vendors/toastr-master/toastr.js');

        Html::instance()->setJs("/assets/modules/recaptcha/js/recaptcha.js");
        Html::instance()->content = $this->render("/recaptcha/Form.php", $data);
        Html::instance()->renderTemplate('@admin')->show();
    }

    public function actionSave()
    {
        $data = $_POST;
        if(empty($data['publickey'])){
            echo json_encode(['error' => 1, 'data' => 'Введите publickey']);
            exit();
        }
        if(empty($data['privatekey'])){
            echo json_encode(['error' => 1, 'data' => 'Введите privatekey']);
            exit();
        }
        if(empty($data['response_name'])){
            echo json_encode(['error' => 1, 'data' => 'Введите response_name']);
            exit();
        }
        if(!isset($data['status'])){
            echo json_encode(['error' => 1, 'data' => 'Введите status']);
            exit();
        }

        $dataRecaptcha=[];
        if(!empty($data['id'])){
            $dataRecaptcha['id'] = $data['id'];
        }

        $dataRecaptcha['publickey'] = $data['publickey'];
        $dataRecaptcha['privatekey'] = $data['privatekey'];
        $dataRecaptcha['response_name'] = $data['response_name'];
        $dataRecaptcha['status'] = $data['status'];

        $idRecaptcha = mRecaptcha::instance()->saveRecaptcha($dataRecaptcha);
        if(!empty($idRecaptcha)){
            echo json_encode(['error' => 0, 'data' => 'Успешно']);
            exit();
        } else {
            echo json_encode(['error' => 1, 'data' => 'Ошибка']);
            exit();
        }
    }

}