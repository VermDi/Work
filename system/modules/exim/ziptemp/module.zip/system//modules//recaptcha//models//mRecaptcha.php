<?php

namespace modules\recaptcha\models;

use core\Model;

/**
 * Class mRecaptcha
 * @property int id -
 * @property string publickey -
 * @property string privatekey -
 * @property string response_name -
 * @property string status -
 */

class mRecaptcha extends Model
{
    public $table = 'recaptcha';

    public function factory($id = false)
    {
        if ($id == false or !$this->getOne($id)) {
            $this->id = "";
            $this->publickey = "";
            $this->privatekey = "";
            $this->response_name = "";
            $this->status = "";
        }
        return $this;
    }

    public function getStatusArr(){
        $TypesArr[0] = 'Выключена';
        $TypesArr[1] = 'Включена';
        return $TypesArr;
    }

    public function getRecaptcha($options = false){
        $q = mRecaptcha::instance();
        if(!isset($options['select'])){
            $options['select'] = mRecaptcha::instance()->table.'.* ';
        }
        $q = $q->select($options['select']);
        if(isset($options['id'])){
            $q = $q->where(mRecaptcha::instance()->table.'.id','=',$options['id']);
        }
        if(isset($options['status'])){
            $q = $q->where(mRecaptcha::instance()->table.'.status','=',$options['status']);
        }
        if(isset($options['offset'])){
            $q = $q->offset($options['offset']);
        }
        if(isset($options['limit'])){
            $q = $q->limit($options['limit']);
        }

        if(isset($options['getCount'])){
            $q = $q->count('*');
            $q = $q->getOne();
            $countName = 'COUNT(*)';
            return $q->$countName;
        }

        if(isset($options['getOne'])){
            $q = $q->getOne();
        } else {
            $q = $q->getAll();
        }
        return $q;
    }

    public function saveRecaptcha($data){
        $id = (isset($data['id'])) ? $data['id'] : false;
        $model = $this->clear();
        $model->factory($id);
        if (!empty($model->id) and !empty($data['id'])) {
            $model->fill($data)->save();
        } else {
            $model->fill($data)->insert();
        }
        if ($model->insertId() != null) {
            $id = $model->insertId();
        }
        return $id;
    }

    public function getActiveRecaptcha($id=1){
        return mRecaptcha::instance()->getRecaptcha(['getOne'=>true, 'status'=>1, 'id'=>$id]);
    }




}