<?php
use core\Migration;
                  
class m200602_114907_recaptcha extends Migration
{
     public function up() {
         $this->query("CREATE TABLE IF NOT EXISTS `recaptcha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publickey` varchar(255) DEFAULT NULL,
  `privatekey` varchar(255) DEFAULT NULL,
  `response_name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `publickey` (`publickey`),
  KEY `privatekey` (`privatekey`),
  KEY `response_name` (`response_name`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;");

         if(class_exists('\modules\menu\services\MenuActions')) {
             \modules\menu\services\MenuActions::addInAdminMenu('/recaptcha', 'reCaptcha');
         }
         return true;
     }
                 
     public function down() {
         $this->query("DROP TABLE IF EXISTS recaptcha");
         return true;
     }
}