# reCaptcha
Вставляйте капчу в любую форму на сайте, на главной странице капчи написана подробная инструкция

## Инструкция

1. Создание рекапчи. Перейдите по ссылке, выберите reCAPTCHA v2 и введите домен

2. Заполните ключ сайта, секретный ключ и нажмите сохранить

3. Вставьте в шаблон

`<?php \modules\recaptcha\widgets\wRecaptcha::showTemplate(); ?>`


4. Вставьте в форму в шаблоне для вывода капчи

`<?php \modules\recaptcha\widgets\wRecaptcha::showForm(); ?>`


5. Вставьте в обработку формы

`<?php if(!\modules\recaptcha\widgets\wRecaptcha::checkForm()){ exit(json_encode(['error' => 1, 'data' => 'Ошибка, Recaptcha не пройдена'])); } ?>`


6. Вставьте в js для сброса капчи

`<script> if(document.getElementsByClassName('g-recaptcha').length){ grecaptcha.reset(); } </script>`
 