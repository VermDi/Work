<?php

namespace modules\aboutproject\controllers;

use core\App;
use core\Controller;
use core\Html;
use modules\aboutproject\models\mAboutProject;
use modules\aboutproject\models\mAboutProjectEdits;
use modules\user\models\USER;

class Aboutproject extends Controller
{

    public function actionIndex()
    {
        header('Location: /aboutproject/aboutproject/list');
    }

    public function actionList($status = 0)
    {
        $data = [];
        $data['status'] = $status;

        Html::instance()->setJs("/assets/vendors/datatables/js/jquery.dataTables.min.js");
        Html::instance()->setCss("/assets/vendors/datatables/css/jquery.dataTables.min.css");

        Html::instance()->setCss('/assets/vendors/jquery.datetimepicker/jquery.datetimepicker.css');
        Html::instance()->setJs('/assets/vendors/jquery.datetimepicker/jquery.datetimepicker.js');

        Html::instance()->setCss('/assets/vendors/toastr-master/toastr.css');
        Html::instance()->setJs('/assets/vendors/toastr-master/toastr.js');

        Html::instance()->setJs("/assets/modules/aboutproject/js/aboutproject.js");

        Html::instance()->content = $this->render("/aboutproject/List.php", $data);
        Html::instance()->renderTemplate('@admin')->show();
    }

    public function actionSave()
    {
        $data = $_POST;
        if(empty($data['name'])){
            echo json_encode(['error' => 1, 'data' => 'Введите Название']);
            exit();
        }
        if(empty($data['description'])){
            echo json_encode(['error' => 1, 'data' => 'Введите Описание']);
            exit();
        }

        $dataAboutProject=[];
        if(!empty($data['id'])){
            $dataAboutProject['id'] = $data['id'];
        } else {
            $dataAboutProject['date'] = date('Y-m-d H:i:s');
        }

        $dataAboutProject['name'] = $data['name'];
        $dataAboutProject['description'] = $data['description'];

        $idAboutProject = mAboutProject::instance()->saveAboutProject($dataAboutProject);
        if(!empty($idAboutProject)){
            $dataGetlist = $this->actionGetlist(false, $idAboutProject, true);
            if(isset($dataGetlist[0])){
                echo json_encode(['error' => 0, 'data' => 'Успешно', 'jsonRow' => json_encode($dataGetlist[0])]);
            }
        }
        exit();
    }

    public function actionGetlist($status = false, $id = false, $getData = false)
    {
        /*
        * для передачи по ajax в формет json
        */
        $options=[];
        if(isset($_GET['start'])){
            $options['offset'] = $_GET['start'];
        }
        if(isset($_GET['length'])){
            $options['limit'] = $_GET['length'];
        }
        if(!empty($id)){
            $options['id'] = $id;
        }
        //$options['offset'] = 0;
        //$options['limit'] = 5;
        $res = mAboutProject::instance()->getAboutProject($options);

        $countAll = mAboutProject::instance()->getAboutProject(['getCount'=>true, 'status'=>$status]);
        //$TypesArr = mAboutProject::instance()->getTypesArr();

        if(!empty($res)){
            foreach ($res as $k => $v) {

                $editsList = '<table class="table-bordered col-md-12">';

                $editsList .= '<tr>';
                $editsList .= '<td>Дата</td>';
                $editsList .= '<td>Пользователь</td>';
                $editsList .= '<td>Название</td>';
                $editsList .= '<td>Управление</td>';
                $editsList .= '</tr>';

                $AboutProjectEdits = mAboutProjectEdits::instance()->getAboutProjectEdits(['about_project_id'=>$v->id]);
                if(is_array($AboutProjectEdits)){
                    foreach ($AboutProjectEdits as $AboutProjectEdit){
                        $editsList .= '<tr>';
                        $editsList .= '<td>'.$AboutProjectEdit->date.'</td>';
                        $editsList .= '<td>'.$AboutProjectEdit->email.'</td>';
                        $editsList .= '<td><a data-title="'.htmlspecialchars($AboutProjectEdit->name).'" href="/aboutproject/aboutproject/textedits/'.$AboutProjectEdit->id.'" class="ajax">'.$AboutProjectEdit->name.'</a></td>';
                        $editsList .= "<td><a data-title='Редактирование' href='/aboutproject/aboutproject/formedits/" . $AboutProjectEdit->id . "/" . $v->id . "' class='btn btn-warning btn-xs ajax'><i class='fa fa-edit'></i></a>
                                <a data-id='" . $AboutProjectEdit->id . "' class='btn btn-danger btn-xs delProjectEdits'><i class='fa fa-trash-o'></i></a></td>";
                        $editsList .= '</tr>';
                    }
                }
                $editsList .= '</table>';

                $editsList .= '<a href="/aboutproject/aboutproject/formedits/0/'.$v->id.'" data-title="Добавление" class="btn btn-xs btn-success ajax">Добавить правку</a>';

                $res[$k]->edits = $editsList;
                //$res[$k]->type = (isset($TypesArr[$v->type]))?$TypesArr[$v->type]:$v->type;

                $res[$k]->description = str_replace("\n", "<br>", $v->description);

                $res[$k]->control = "<a data-title='Редактирование' href='/aboutproject/aboutproject/form/" . $v->id . "/ajax' class='btn btn-warning btn-xs ajax'><i class='fa fa-edit'></i></a>
                                <a data-id='" . $v->id . "' class='btn btn-danger btn-xs delProject'><i class='fa fa-trash-o'></i></a>";
            }
        } else {
            $res = [];
        }
        /*echo '<pre>';
        print_r($res);
        echo '</pre>';
        exit;*/

        if(!empty($getData)){
            return $res;
        } else {
            echo json_encode(['data'=>$res, 'recordsTotal'=>$countAll, 'recordsFiltered'=>$countAll]);
        }
        die();
    }

    public function actionForm($id = false, $ajax = false)
    {
        if ($id == 0) {
            $id = false;
        }
        $data['model'] = mAboutProject::instance()->factory($id);
        echo $this->render("/aboutproject/Form.php", $data);
        die();
    }

    public function actionFormedits($id, $about_project_id)
    {
        if ($id == 0) {
            $id = false;
        }
        $data['model'] = mAboutProjectEdits::instance()->factory($id);
        $data['about_project_id'] = $about_project_id;
        echo $this->render("/aboutproject/FormEdits.php", $data);
        die();
    }

    public function actionTextedits($id)
    {
        $AboutProjectEdits = mAboutProjectEdits::instance()->getAboutProjectEdits(['id'=>$id, 'getOne'=>true]);
        if(isset($AboutProjectEdits->description)){
            echo str_replace("\n", "<br>", $AboutProjectEdits->description);
        }
    }

    public function actionSaveedits()
    {
        $data = $_POST;
        if(empty($data['name'])){
            echo json_encode(['error' => 1, 'data' => 'Введите Название']);
            exit();
        }
        if(empty($data['description'])){
            echo json_encode(['error' => 1, 'data' => 'Введите Описание']);
            exit();
        }

        $dataAboutProjectEdits=[];
        if(!empty($data['id'])){
            $dataAboutProjectEdits['id'] = $data['id'];
        } else {
            $dataAboutProjectEdits['date'] = date('Y-m-d H:i:s');
        }

        $dataAboutProjectEdits['name'] = $data['name'];
        $dataAboutProjectEdits['description'] = $data['description'];

        $dataAboutProjectEdits['user_id'] = USER::current()->id;

        $dataAboutProjectEdits['about_project_id'] = $data['about_project_id'];

        $idAboutProjectEdits = mAboutProjectEdits::instance()->saveAboutProjectEdits($dataAboutProjectEdits);
        if(!empty($idAboutProjectEdits)){
            $dataGetlist = $this->actionGetlist(false, $dataAboutProjectEdits['about_project_id'], true);
            if(isset($dataGetlist[0])){
                echo json_encode(['error' => 0, 'data' => 'Успешно', 'jsonRow' => json_encode($dataGetlist[0])]);
            }
        }
        exit();
    }

    public function actionDeledits($id = false)
    {
        mAboutProjectEdits::instance()->delete($id);
        echo 1;
    }

    public function actionDel($id = false)
    {
        mAboutProject::instance()->delete($id);
        echo 1;
    }

}