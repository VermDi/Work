<?php

namespace modules\backups\controllers;

use core\App;
use core\Controller;
use core\Html;
use modules\backups\models\mBackups;
use modules\backups\services\sBackups;
use modules\user\models\USER;

class Cron extends Controller
{

    public function actionSave()
    {
        $data = $_REQUEST;
        if(!isset($data['key'])){
            echo json_encode(['error' => 1, 'data' => 'key не найден']);
            exit();
        }
        if($data['key']!=_SECRET_KEY_){
            echo json_encode(['error' => 1, 'data' => 'key не работает']);
            exit();
        }

        $Backup = new Backup;
        $Backup->actionSave();
    }

}