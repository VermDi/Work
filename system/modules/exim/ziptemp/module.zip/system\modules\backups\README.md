# backups - Создание резервных копий файлов и БД
Для создания резервной копии удаленно, запустите ссылку
http://домен/backups/backup/save?comments=auto&db=1&files=1&exclude_folder=www/public/