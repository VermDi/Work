<?php
return [
    'version' => '1.1',
    'ModuleInfo' => [
        'name' => 'backups',
        'version_description' => 'Cron с ключом и копии из файлов ',
        'link_home' => '/backups',
    ],
    'Folders' => [ // папки для архивации. По умолчанию system/modules/NameModule и www/assets/modules/NameModule
        'system/modules/backups',
        'www/assets/modules/backups',
    ],
    'requireModules' => [ // дополнительные модули, которые требует данный модуль чтобы работать. По умолчанию их нет
    ],
];
