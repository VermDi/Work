<?php include __DIR__.'/menu.php'; ?>
<?php
$HomeUri = '/';
if (isset($_SERVER['HTTP_HOST'])) {
    $protokol = isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
    $HomeUri = $protokol . $_SERVER['HTTP_HOST'];
}

$url = $HomeUri.'/backups/cron/save?comments=auto&db=1&files=1&exclude_folder=www/public/&key='._SECRET_KEY_;
?>
<div class="page-header clearfix panel">
    <div class="col-sm-6 pull-left" style="font-size: 17px; padding-top: 4px;">
        <div class="pull-left">
            Копии из файлов
        </div>
    </div>
</div>
<div class="panel-body panel">
    <p>Для создания резервной копии удаленно запустите ссылку<br>
        <a target="_blank" href="<?= $url ?>"><?= $url ?></a></p>
    <?php
    $FilesArr = \modules\backups\services\sBackups::instance()->getFiles();
    $TypesArr = \modules\backups\models\mBackups::instance()->getTypesArr();
    ?>
    <table class="table table-striped table-hover table-bordered responsive TableProjectFiles">
        <thead>
        <tr>
            <th width="50">#</th>
            <th>Тип</th>
            <th>Файл</th>
            <th width="200" data-orderable="false">Управление</th>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach ($FilesArr as $FileRow){
        ?>
            <tr>
                <td width="50">#</td>
                <td><?= (isset($TypesArr[$FileRow['type']]))?$TypesArr[$FileRow['type']]:'' ?></td>
                <td><?= $FileRow['fileName'] ?></td>
                <td width="100" data-orderable="false">
                    <?php
                    if($FileRow['type']==1){
                    ?>
                        <a class="btn btn-xs btn-info" href="<?= $FileRow['file'] ?>">Скачать .sql</a>
                        <a class="btn btn-xs btn-info BackupDbRestore" href="#" data-dbfile="<?= $FileRow['file'] ?>">Восстановить</a>
                        <?php
                    }
                    if($FileRow['type']==2){
                        ?>
                        <a class="btn btn-xs btn-info" href="<?= $FileRow['file'] ?>">Скачать .zip</a>
                        <a class="btn btn-xs btn-info BackupRestore" href="#" data-files="<?= $FileRow['file'] ?>">Восстановить</a>
                        <?php
                    }
                    ?>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="Form">
    <div class="modal-dialog modal-lg modal-full" style="height: 100%;">
        <div class="modal-content" style="height: 90%; overflow-y: scroll;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="ContentTitle"></h4>
            </div>
            <div class="modal-body clearfix" id="AjaxContent">

            </div>
        </div>
    </div>
</div>
