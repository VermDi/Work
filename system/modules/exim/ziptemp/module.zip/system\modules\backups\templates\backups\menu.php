<p>
    <a class="btn btn-success" href="/backups/backup/list">Таблица из БД</a>
    <a class="btn btn-success" href="/backups/backup/listfiles">Таблица из Файлов</a>
</p>